from __future__ import annotations

import argparse
import os
from pathlib import Path

from trailtraining.commands.common import _run
from trailtraining.llm.rubrics import default_primary_goal_for_style


def _resolve_lifestyle_notes(args: argparse.Namespace) -> str:
    """Resolve lifestyle notes from CLI flag or env var."""
    cli_val: str = str(getattr(args, "lifestyle_notes", None) or "")
    if cli_val.strip():
        return cli_val.strip()
    return (os.getenv("TRAILTRAINING_LIFESTYLE_NOTES") or "").strip()


def cmd_coach(args: argparse.Namespace) -> None:
    from trailtraining.llm.coach import CoachConfig, run_coach_brief

    def _inner() -> None:
        base_cfg = CoachConfig.from_env()
        style = args.style or base_cfg.style or "trailrunning"
        primary_goal = (
            args.goal
            or os.getenv("TRAILTRAINING_PRIMARY_GOAL")
            or default_primary_goal_for_style(style)
        )
        lifestyle_notes = _resolve_lifestyle_notes(args) or base_cfg.lifestyle_notes

        cfg = CoachConfig(
            model=args.model or base_cfg.model,
            reasoning_effort=args.reasoning_effort or base_cfg.reasoning_effort,
            verbosity=args.verbosity or base_cfg.verbosity,
            days=args.days if args.days is not None else base_cfg.days,
            max_chars=args.max_chars if args.max_chars is not None else base_cfg.max_chars,
            temperature=args.temperature,
            style=style,
            primary_goal=primary_goal,
            plan_days=getattr(args, "plan_days", None) or base_cfg.plan_days,
            lifestyle_notes=lifestyle_notes,
        )
        text, out_path = run_coach_brief(
            prompt=args.prompt,
            cfg=cfg,
            input_path=args.input,
            personal_path=args.personal,
            summary_path=args.summary,
            output_path=args.output,
        )
        print(text)
        if out_path:
            print(f"\n[Saved] {out_path}")
            if args.prompt == "training-plan":
                p = Path(out_path)
                txt_p = p.parent / f"{p.stem}.txt"
                if txt_p.exists():
                    print(f"[Saved] {txt_p}")

    _run(_inner)


def cmd_eval_coach(args: argparse.Namespace) -> None:
    from trailtraining import config
    from trailtraining.llm.constraints import constraint_config_from_env
    from trailtraining.llm.eval import evaluate_training_plan_quality_file
    from trailtraining.llm.soft_eval import SoftEvalConfig
    from trailtraining.util.state import save_json

    def _inner() -> None:
        runtime = config.current()
        prompting_dir = Path(runtime.paths.prompting_directory)

        input_path = args.input or str(prompting_dir / "coach_brief_training-plan.json")
        report_path = args.report or str(prompting_dir / "eval_report.json")

        cfg = constraint_config_from_env(
            max_ramp_pct=float(args.max_ramp_pct),
            max_consecutive_hard=int(args.max_consecutive_hard),
        )

        soft_cfg = None
        if getattr(args, "soft_eval", False):
            default_soft = SoftEvalConfig.from_env()
            lifestyle_notes = _resolve_lifestyle_notes(args) or default_soft.lifestyle_notes
            soft_cfg = SoftEvalConfig(
                enabled=True,
                model=args.soft_eval_model or default_soft.model,
                reasoning_effort=(
                    getattr(args, "soft_eval_reasoning_effort", None)
                    or default_soft.reasoning_effort
                ),
                verbosity=(getattr(args, "soft_eval_verbosity", None) or default_soft.verbosity),
                primary_goal=args.goal or default_soft.primary_goal,
                lifestyle_notes=lifestyle_notes,
                skip_synthesis=getattr(args, "skip_synthesis", False)
                or default_soft.skip_synthesis,
                parallel_batches=(
                    not getattr(args, "no_parallel_batches", False)
                    and default_soft.parallel_batches
                ),
            )

        soft_eval_runs = max(1, int(getattr(args, "soft_eval_runs", 1) or 1))

        report, _obj = evaluate_training_plan_quality_file(
            input_path,
            rollups_path=args.rollups,
            cfg=cfg,
            soft_eval_cfg=soft_cfg,
            primary_goal=args.goal,
            soft_eval_runs=soft_eval_runs,
        )
        violations = report.get("violations", [])

        if args.output:
            outp = Path(args.output).expanduser().resolve()
            save_json(outp, violations, compact=False)
            print(f"[Saved] {outp}")

        outp = Path(report_path).expanduser().resolve()
        save_json(outp, report, compact=False)
        print(f"[Saved] {outp}")

        score = report.get("score", 0)
        grade = report.get("grade", "?")
        print(f"Deterministic score: {score}/100 ({grade})")

        subs = report.get("subscores", {}) or {}
        if subs:
            parts = [f"{k}={subs[k]}" for k in sorted(subs.keys())]
            print("Deterministic subscores:", ", ".join(parts))

        soft = report.get("soft_assessment") or {}
        if isinstance(soft, dict) and soft:
            soft_score = soft.get("overall_score", 0)
            soft_grade = soft.get("grade", "?")
            print(f"Soft quality score: {soft_score}/100 ({soft_grade})")

            rubric_scores = soft.get("rubric_scores", {}) or {}
            if rubric_scores:
                parts = []
                for key in sorted(rubric_scores.keys()):
                    item = rubric_scores.get(key) or {}
                    parts.append(f"{key}={item.get('score', 0)}")
                print("Rubric scores:", ", ".join(parts))

            stats = report.get("stats", {}) or {}
            n_runs = stats.get("inter_rater_runs")
            if n_runs and int(n_runs) > 1:
                print(f"Inter-rater runs: {n_runs}")
                method = str(stats.get("inter_rater_consensus_method", "") or "").strip()
                if method:
                    print(f"Consensus method: {method}")
                high_var = stats.get("high_variance_markers", {})
                if high_var:
                    flagged = ", ".join(
                        f"{mid}(std={std:.2f})" for mid, std in sorted(high_var.items())
                    )
                    print(f"High-variance markers (ambiguous rubrics): {flagged}")

        if not violations:
            print("eval-coach: no violations")
            raise SystemExit(0)

        print("eval-coach violations:")
        for violation in violations:
            sev = violation.get("severity", "unknown")
            code = violation.get("code", "UNKNOWN")
            msg = violation.get("message", "")
            print(f"- [{sev}] {code}: {msg}")

        if any(v.get("severity") == "high" for v in violations):
            raise SystemExit(1)
        raise SystemExit(0)

    _run(_inner)


def cmd_revise_plan(args: argparse.Namespace) -> None:
    from trailtraining import config
    from trailtraining.llm.coach import CoachConfig
    from trailtraining.llm.revise import RevisePlanConfig, run_revise_plan

    def _inner() -> None:
        runtime = config.current()
        prompting_dir = Path(runtime.paths.prompting_directory)

        base_cfg = CoachConfig.from_env()
        lifestyle_notes = _resolve_lifestyle_notes(args) or base_cfg.lifestyle_notes

        revise_cfg = RevisePlanConfig(
            model=args.model or base_cfg.model,
            reasoning_effort=args.reasoning_effort or base_cfg.reasoning_effort,
            verbosity=args.verbosity or base_cfg.verbosity,
            temperature=args.temperature,
            primary_goal=args.goal or base_cfg.primary_goal,
            lifestyle_notes=lifestyle_notes,
        )

        input_path = args.input or str(prompting_dir / "coach_brief_training-plan.json")
        report_path = args.report or str(prompting_dir / "eval_report.json")
        auto_reeval = bool(getattr(args, "auto_reeval", False))

        text, out_path = run_revise_plan(
            cfg=revise_cfg,
            input_plan_path=input_path,
            eval_report_path=report_path,
            output_path=args.output,
            rollups_path=args.rollups,
            auto_reeval=auto_reeval,
        )

        print(text)
        if out_path:
            print(f"\n[Saved] {out_path}")
            p = Path(out_path)
            txt_p = p.parent / f"{p.stem}.txt"
            if txt_p.exists():
                print(f"[Saved] {txt_p}")
            comparison_p = p.parent / f"{p.stem}-comparison.json"
            if comparison_p.exists():
                print(f"[Saved] {comparison_p}")
            if auto_reeval:
                reeval_p = p.parent / f"{p.stem}-reeval.json"
                if reeval_p.exists():
                    print(f"[Saved] {reeval_p}")

    _run(_inner)
