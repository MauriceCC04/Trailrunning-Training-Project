from __future__ import annotations

import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Optional

from trailtraining.contracts import SoftAssessmentArtifact
from trailtraining.llm.rubrics import (
    DEFAULT_PRIMARY_GOAL,
    _normalize_style,
    default_primary_goal_for_style,
    get_default_rubrics,
    grade_from_score,
    render_rubric_batch_for_prompt,
    render_rubrics_for_prompt,
    weighted_score_from_rubric_scores,
)
from trailtraining.llm.shared import call_with_schema, extract_json_object, make_openrouter_client
from trailtraining.util.text import _safe_json_snippet

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Rubric batches for decomposed evaluation
# ---------------------------------------------------------------------------
_RUBRIC_BATCHES: list[tuple[str, list[str]]] = [
    ("goal_coherence", ["goal_alignment", "plan_coherence"]),
    ("explanation", ["explanation_quality"]),
    ("caution", ["caution_proportionality"]),
    ("actionability", ["actionability"]),
]


@dataclass(frozen=True)
class SoftEvalConfig:
    enabled: bool = False
    model: str = "anthropic/claude-sonnet-4"
    reasoning_effort: str = "medium"
    verbosity: str = "medium"
    temperature: Optional[float] = None
    primary_goal: Optional[str] = None
    lifestyle_notes: str = ""
    skip_synthesis: bool = False
    parallel_batches: bool = True

    @classmethod
    def from_env(cls) -> SoftEvalConfig:
        return cls(
            enabled=False,
            model=os.getenv("TRAILTRAINING_SOFT_EVAL_MODEL", cls.model),
            reasoning_effort=os.getenv(
                "TRAILTRAINING_SOFT_EVAL_REASONING_EFFORT",
                cls.reasoning_effort,
            ),
            verbosity=os.getenv(
                "TRAILTRAINING_SOFT_EVAL_VERBOSITY",
                cls.verbosity,
            ),
            primary_goal=os.getenv("TRAILTRAINING_PRIMARY_GOAL") or None,
            lifestyle_notes=os.getenv("TRAILTRAINING_LIFESTYLE_NOTES", "").strip(),
            skip_synthesis=(
                os.getenv("TRAILTRAINING_SOFT_EVAL_SKIP_SYNTHESIS", "").strip().lower()
                in {"1", "true", "yes", "y", "on"}
            ),
            parallel_batches=(
                os.getenv("TRAILTRAINING_SOFT_EVAL_NO_PARALLEL", "").strip().lower()
                not in {"1", "true", "yes", "y", "on"}
            ),
        )


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


def _rubric_ids() -> list[str]:
    return [r.rubric_id for r in get_default_rubrics("trailrunning")]


def _build_batch_marker_schema(batch_name: str) -> dict[str, Any]:
    return {
        "name": f"trailtraining_batch_{batch_name}_v1",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "required": ["marker_results"],
            "properties": {
                "marker_results": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "rubric",
                            "marker_id",
                            "marker",
                            "observation",
                            "verdict",
                            "score",
                            "evidence",
                            "improvement_hint",
                        ],
                        "properties": {
                            "rubric": {"type": "string"},
                            "marker_id": {"type": "string"},
                            "marker": {"type": "string"},
                            "observation": {
                                "type": "string",
                                "description": (
                                    "What you observe in the plan relevant to this marker. "
                                    "Write this BEFORE deciding the score."
                                ),
                            },
                            "verdict": {
                                "type": "string",
                                "enum": ["pass", "partial", "fail"],
                            },
                            "score": {"type": "number", "minimum": 0, "maximum": 5},
                            "evidence": {"type": "string"},
                            "improvement_hint": {"type": "string"},
                        },
                    },
                }
            },
        },
    }


_SYNTHESIS_SCHEMA: dict[str, Any] = {
    "name": "trailtraining_soft_eval_synthesis_v1",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["summary", "confidence", "strengths", "concerns", "suggested_improvements"],
        "properties": {
            "summary": {"type": "string"},
            "confidence": {"type": "string", "enum": ["low", "medium", "high"]},
            "strengths": {"type": "array", "items": {"type": "string"}},
            "concerns": {"type": "array", "items": {"type": "string"}},
            "suggested_improvements": {"type": "array", "items": {"type": "string"}},
        },
    },
}

_COMPARE_PLANS_SCHEMA: dict[str, Any] = {
    "name": "trailtraining_compare_plans_v1",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["preferred", "reasoning", "plan_a_advantages", "plan_b_advantages"],
        "properties": {
            "preferred": {"type": "string", "enum": ["plan_a", "plan_b", "tie"]},
            "reasoning": {"type": "string"},
            "plan_a_advantages": {"type": "array", "items": {"type": "string"}},
            "plan_b_advantages": {"type": "array", "items": {"type": "string"}},
        },
    },
}

SOFT_EVAL_SCHEMA: dict[str, Any] = {
    "name": "trailtraining_soft_quality_assessment_v1",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "summary",
            "confidence",
            "rubric_scores",
            "marker_results",
            "strengths",
            "concerns",
            "suggested_improvements",
        ],
        "properties": {
            "summary": {"type": "string"},
            "confidence": {"type": "string", "enum": ["low", "medium", "high"]},
            "rubric_scores": {
                "type": "object",
                "additionalProperties": False,
                "required": _rubric_ids(),
                "properties": {
                    rubric_id: {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["score", "reasoning"],
                        "properties": {
                            "score": {"type": "number", "minimum": 0, "maximum": 100},
                            "reasoning": {"type": "string"},
                        },
                    }
                    for rubric_id in _rubric_ids()
                },
            },
            "marker_results": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": [
                        "rubric",
                        "marker_id",
                        "marker",
                        "verdict",
                        "score",
                        "evidence",
                        "improvement_hint",
                    ],
                    "properties": {
                        "rubric": {"type": "string"},
                        "marker_id": {"type": "string"},
                        "marker": {"type": "string"},
                        "observation": {"type": "string"},
                        "verdict": {
                            "type": "string",
                            "enum": ["pass", "partial", "fail"],
                        },
                        "score": {"type": "number", "minimum": 0, "maximum": 5},
                        "evidence": {"type": "string"},
                        "improvement_hint": {"type": "string"},
                    },
                },
            },
            "strengths": {"type": "array", "items": {"type": "string"}},
            "concerns": {"type": "array", "items": {"type": "string"}},
            "suggested_improvements": {"type": "array", "items": {"type": "string"}},
        },
    },
}


def _marker_only_schema() -> dict[str, Any]:
    return {
        "name": "trailtraining_soft_quality_markers_v1",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "required": ["marker_results"],
            "properties": {
                "marker_results": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "rubric",
                            "marker_id",
                            "marker",
                            "verdict",
                            "score",
                            "evidence",
                            "improvement_hint",
                        ],
                        "properties": {
                            "rubric": {"type": "string"},
                            "marker_id": {"type": "string"},
                            "marker": {"type": "string"},
                            "observation": {"type": "string"},
                            "verdict": {
                                "type": "string",
                                "enum": ["pass", "partial", "fail"],
                            },
                            "score": {"type": "number", "minimum": 0, "maximum": 5},
                            "evidence": {"type": "string"},
                            "improvement_hint": {"type": "string"},
                        },
                    },
                }
            },
        },
    }


# ---------------------------------------------------------------------------
# Normalisation helpers
# ---------------------------------------------------------------------------


def _normalize_confidence(value: Any) -> str:
    s = str(value or "").strip().lower()
    if s in {"low", "medium", "high"}:
        return s
    return "medium"



def _normalize_verdict(value: Any, score: float) -> str:
    s = str(value or "").strip().lower()
    if s in {"pass", "partial", "fail"}:
        return s
    if score >= 4.0:
        return "pass"
    if score >= 2.0:
        return "partial"
    return "fail"



def _clean_string_list(raw: Any) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in raw or []:
        s = " ".join(str(item).split()).strip()
        if not s:
            continue
        key = s.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out



def _build_feedback_lists(
    raw: dict[str, Any],
    rubric_scores: dict[str, dict[str, Any]],
    marker_results: list[dict[str, Any]],
) -> tuple[list[str], list[str], list[str], list[str]]:
    strengths = _clean_string_list(raw.get("strengths"))
    concerns = _clean_string_list(raw.get("concerns"))
    improvements = _clean_string_list(raw.get("suggested_improvements"))
    derived_fields: list[str] = []

    if len(strengths) < 2:
        derived_fields.append("strengths")
        for _, rubric_score in sorted(
            rubric_scores.items(),
            key=lambda kv: float((kv[1] or {}).get("score", 0)),
            reverse=True,
        ):
            reasoning = str((rubric_score or {}).get("reasoning", "")).strip()
            if reasoning and reasoning not in strengths:
                strengths.append(reasoning)
            if len(strengths) >= 3:
                break

    weaker_markers = sorted(
        marker_results,
        key=lambda marker: float(marker.get("score", 0)),
    )

    if len(concerns) < 1:
        derived_fields.append("concerns")
        for marker in weaker_markers:
            evidence = str(marker.get("evidence", "")).strip()
            label = str(marker.get("marker", "")).strip()
            if evidence:
                text = f"{label}: {evidence}" if label else evidence
                if text not in concerns:
                    concerns.append(text)
            if len(concerns) >= 2:
                break

    if len(improvements) < 2:
        derived_fields.append("suggested_improvements")
        for marker in weaker_markers:
            hint = str(marker.get("improvement_hint", "")).strip()
            if hint and hint not in improvements:
                improvements.append(hint)
            if len(improvements) >= 3:
                break

    if len(strengths) < 2:
        for fallback_strength in [
            "The plan contains concrete and executable session structure.",
            "The week shows a clear training purpose across sessions.",
        ]:
            if fallback_strength not in strengths:
                strengths.append(fallback_strength)
            if len(strengths) >= 2:
                break

    if len(concerns) < 1:
        concerns = ["Some parts of the plan could be more specific or better justified."]

    if len(improvements) < 2:
        for fallback_improvement in [
            "Add more specific execution guidance for key sessions.",
            "Clarify progression and recovery logic where useful.",
        ]:
            if fallback_improvement not in improvements:
                improvements.append(fallback_improvement)
            if len(improvements) >= 2:
                break

    return strengths[:4], concerns[:3], improvements[:4], sorted(set(derived_fields))



def _expected_markers(style: str) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for rubric in get_default_rubrics(style):
        for marker in rubric.markers:
            out.append(
                {"rubric": rubric.rubric_id, "marker_id": marker.marker_id, "marker": marker.label}
            )
    return out



def _expected_markers_for_rubrics(rubric_ids: list[str], style: str) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for rubric in get_default_rubrics(style):
        if rubric.rubric_id not in rubric_ids:
            continue
        for marker in rubric.markers:
            out.append(
                {"rubric": rubric.rubric_id, "marker_id": marker.marker_id, "marker": marker.label}
            )
    return out



def _normalize_marker_results(raw: list[Any], *, style: str) -> list[dict[str, Any]]:
    rubrics = get_default_rubrics(style)
    by_marker: dict[str, dict[str, Any]] = {}
    for item in raw:
        if isinstance(item, dict) and isinstance(item.get("marker_id"), str):
            by_marker[item["marker_id"]] = item

    out: list[dict[str, Any]] = []
    for rubric in rubrics:
        for marker in rubric.markers:
            item = by_marker.get(marker.marker_id, {})
            try:
                score = float(item.get("score", 0))
            except (TypeError, ValueError):
                score = 0.0
            score = max(0.0, min(5.0, score))
            verdict = _normalize_verdict(item.get("verdict"), score)
            observation_raw = str(item.get("observation", "") or "").strip()
            out.append(
                {
                    "rubric": rubric.rubric_id,
                    "marker_id": marker.marker_id,
                    "marker": marker.label,
                    "verdict": verdict,
                    "score": round(score, 1),
                    "observation": observation_raw if observation_raw else None,
                    "evidence": str(item.get("evidence", "") or "").strip(),
                    "improvement_hint": str(item.get("improvement_hint", "") or "").strip(),
                }
            )
    return out



def _normalize_rubric_scores(raw: Any, *, style: str) -> dict[str, dict[str, Any]]:
    rubrics = get_default_rubrics(style)
    raw_dict = raw if isinstance(raw, dict) else {}
    out: dict[str, dict[str, Any]] = {}
    for rubric in rubrics:
        item = raw_dict.get(rubric.rubric_id, {})
        if not isinstance(item, dict):
            item = {}
        try:
            score = float(item.get("score", 0))
        except (TypeError, ValueError):
            score = 0.0
        score = max(0.0, min(100.0, score))
        out[rubric.rubric_id] = {
            "score": round(score, 1),
            "reasoning": str(item.get("reasoning", "") or "").strip(),
        }
    return out



def _resolve_style_goal_and_lifestyle(
    plan_obj: dict[str, Any],
    cfg: SoftEvalConfig,
) -> tuple[str, str, str]:
    """Extract style, primary_goal, and lifestyle_notes from plan + config.

    Priority for lifestyle_notes:
      1. cfg.lifestyle_notes (explicit CLI/env override)
      2. plan_obj.meta.lifestyle_notes (recorded in the artifact)
    """
    meta = plan_obj.get("meta") or {}
    style = _normalize_style(meta.get("style"))
    primary_goal = (
        str(cfg.primary_goal or "").strip()
        or str(meta.get("primary_goal") or "").strip()
        or default_primary_goal_for_style(style)
        or DEFAULT_PRIMARY_GOAL
    )
    lifestyle_notes = (
        str(cfg.lifestyle_notes or "").strip() or str(meta.get("lifestyle_notes") or "").strip()
    )
    return style, primary_goal, lifestyle_notes


# Keep backward-compatible alias used in compare_plans

def _resolve_style_and_goal(
    plan_obj: dict[str, Any],
    cfg: SoftEvalConfig,
) -> tuple[str, str]:
    style, goal, _ = _resolve_style_goal_and_lifestyle(plan_obj, cfg)
    return style, goal



def _rubric_scores_look_usable(raw: Any, *, style: str) -> bool:
    if not isinstance(raw, dict):
        return False
    for rubric in get_default_rubrics(style):
        item = raw.get(rubric.rubric_id)
        if not isinstance(item, dict):
            return False
        raw_score = item.get("score")
        if raw_score is None:
            return False
        try:
            score = float(raw_score)
        except (TypeError, ValueError):
            return False
        if not 0.0 <= score <= 100.0:
            return False
    return True



def _derive_rubric_scores_from_markers(
    marker_results: list[dict[str, Any]],
    *,
    style: str,
) -> dict[str, dict[str, Any]]:
    rubrics = get_default_rubrics(style)
    by_rubric: dict[str, list[float]] = {rubric.rubric_id: [] for rubric in rubrics}
    for item in marker_results:
        rubric_id = str(item.get("rubric", "") or "").strip()
        if rubric_id not in by_rubric:
            continue
        try:
            score = float(item.get("score", 0))
        except (TypeError, ValueError):
            score = 0.0
        score = max(0.0, min(5.0, score))
        by_rubric[rubric_id].append(score)

    out: dict[str, dict[str, Any]] = {}
    for rubric in rubrics:
        vals = by_rubric.get(rubric.rubric_id, [])
        if vals:
            rubric_score = round((sum(vals) / len(vals)) * 20.0, 1)
            reasoning = "Derived from marker scores (per-rubric batch evaluation)."
        else:
            rubric_score = 0.0
            reasoning = "No marker evidence available to derive a rubric score."
        out[rubric.rubric_id] = {"score": rubric_score, "reasoning": reasoning}
    return out



def _parse_soft_eval_json(out_text: str) -> dict[str, Any]:
    raw = json.loads(extract_json_object(out_text))
    if not isinstance(raw, dict):
        raise ValueError("Soft evaluator did not return a JSON object.")
    return raw


# ---------------------------------------------------------------------------
# Lifestyle constraints prompt section
# ---------------------------------------------------------------------------


def _lifestyle_context_for_eval(lifestyle_notes: str) -> list[str]:
    """Build the evaluator-facing lifestyle constraints section.

    This tells the soft evaluator how to interpret plan choices that look
    suboptimal in isolation but are correct given the athlete's schedule.
    """
    notes = lifestyle_notes.strip() if isinstance(lifestyle_notes, str) else ""
    if not notes:
        return []
    return [
        "## Lifestyle constraints (IMPORTANT - affects how you score)",
        f"The athlete has declared these schedule/lifestyle constraints: {notes}",
        "",
        "When scoring markers, account for these constraints:",
        "- trail_specificity: Do NOT penalize road/flat sessions on days where the athlete's",
        "  schedule restricts them to road-only access. Trail-specific work on the permitted",
        "  mountain day(s) is sufficient.",
        "- non_competing_focus: Do NOT flag cycling or cross-training sessions as 'non-running",
        "  without rationale' if the athlete's constraints make cycling a sensible weekday option.",
        "  The rationale IS the schedule constraint.",
        "- workout_purpose_fit / session_type_purpose_alignment: Road-based sessions that serve",
        "  trail-goal fitness (e.g. road tempo for lactate work, road easy runs for aerobic base)",
        "  should be scored as purposeful, not as a failure of trail specificity.",
        "- In general: score the plan against the BEST plan possible GIVEN these constraints,",
        "  not against an idealized unconstrained trail plan.",
        "",
    ]



def _few_shot_examples_for_batch(rubric_ids: list[str], *, style: str) -> list[str]:
    """Return compact rubric-local examples for the batch prompt.

    These are intentionally small. The goal is to anchor score interpretation
    and JSON structure without overwhelming the real plan context.
    """
    if not rubric_ids:
        return []

    lines: list[str] = [
        "## Few-shot examples (illustrative mini-cases)",
        "These are SHORT examples showing how to score this kind of rubric.",
        "In the real answer, you MUST still score every expected marker_id for the actual plan.",
        "",
    ]

    rubric_set = set(rubric_ids)

    if {"goal_alignment", "plan_coherence"} & rubric_set:
        if style == "triathlon":
            strong_case = {
                "plan_snippet": (
                    "Tue threshold bike, Wed easy run, Thu swim drills, Sat long ride with brick run, "
                    "Sun recovery swim. Hard sessions are separated and all three disciplines appear."
                ),
                "marker_results": [
                    {
                        "rubric": "goal_alignment",
                        "marker_id": "discipline_balance",
                        "marker": "Discipline balance",
                        "observation": "The week includes swim, bike, and run with one key bike session and one brick.",
                        "verdict": "pass",
                        "score": 4.5,
                        "evidence": "Tue threshold bike; Thu swim drills; Sat long ride + brick run; Sun recovery swim.",
                        "improvement_hint": "Add race-pace detail to one discipline if the athlete is close to an event.",
                    },
                    {
                        "rubric": "plan_coherence",
                        "marker_id": "hard_easy_spacing",
                        "marker": "Hard/easy spacing",
                        "observation": "The harder sessions are separated by easier or lower-stress days.",
                        "verdict": "pass",
                        "score": 4.0,
                        "evidence": "Threshold bike Tuesday is followed by easy run Wednesday before the next key session.",
                        "improvement_hint": "Keep the same spacing pattern if adding another hard session later.",
                    },
                ],
            }
            weak_case = {
                "plan_snippet": (
                    "Five straight hard run sessions, no swim, one token bike ride, and no rest day."
                ),
                "marker_results": [
                    {
                        "rubric": "goal_alignment",
                        "marker_id": "discipline_balance",
                        "marker": "Discipline balance",
                        "observation": "The week is almost entirely run-focused despite a triathlon goal.",
                        "verdict": "fail",
                        "score": 1.0,
                        "evidence": "No swim sessions and only one token bike ride appear in the week.",
                        "improvement_hint": "Redistribute stress across swim, bike, and run instead of stacking run load only.",
                    },
                    {
                        "rubric": "plan_coherence",
                        "marker_id": "week_coherence",
                        "marker": "Week coherence (score last)",
                        "observation": "Cumulative fatigue would rise unchecked because the week lacks recovery and discipline balance.",
                        "verdict": "fail",
                        "score": 1.0,
                        "evidence": "Five hard run days are placed back-to-back with no real recovery day.",
                        "improvement_hint": "Insert recovery days and distribute key stress across disciplines.",
                    },
                ],
            }
        else:
            strong_case = {
                "plan_snippet": (
                    "Tue hill reps, Wed easy road run, Sat long trail run with climbing, Sun rest. "
                    "One weekday bike ride is explicitly framed as low-impact aerobic support."
                ),
                "marker_results": [
                    {
                        "rubric": "goal_alignment",
                        "marker_id": "trail_specificity",
                        "marker": "Trail specificity",
                        "observation": "The key sessions target trail demands through climbing and long trail-specific durability work.",
                        "verdict": "pass",
                        "score": 4.5,
                        "evidence": "Tue hill reps and Sat long trail run with climbing are explicit.",
                        "improvement_hint": "Add descending technique cues if technical downhill running is a race limiter.",
                    },
                    {
                        "rubric": "plan_coherence",
                        "marker_id": "hard_easy_spacing",
                        "marker": "Hard/easy spacing",
                        "observation": "The harder trail sessions are separated by a clearly easier day and followed by rest.",
                        "verdict": "pass",
                        "score": 4.0,
                        "evidence": "Wed easy road run sits between Tue hills and Sat long trail work; Sun is rest.",
                        "improvement_hint": "Preserve this spacing if adding one more quality session in a future week.",
                    },
                ],
            }
            weak_case = {
                "plan_snippet": (
                    "Mon intervals, Tue tempo, Wed hill sprints, Thu long run at race pace, Fri hard strength, no rest day."
                ),
                "marker_results": [
                    {
                        "rubric": "goal_alignment",
                        "marker_id": "non_competing_focus",
                        "marker": "Non-competing focus",
                        "observation": "Extra work adds fatigue but is not connected to the trail goal or recovery needs.",
                        "verdict": "fail",
                        "score": 1.0,
                        "evidence": "Hard strength and extra sessions are added without any rationale tying them to the race goal.",
                        "improvement_hint": "Keep non-running work only when it clearly supports durability, recovery, or schedule constraints.",
                    },
                    {
                        "rubric": "plan_coherence",
                        "marker_id": "week_coherence",
                        "marker": "Week coherence (score last)",
                        "observation": "The week stacks hard stress without recovery, so fatigue would likely accumulate unsustainably.",
                        "verdict": "fail",
                        "score": 1.0,
                        "evidence": "Multiple hard days appear back-to-back and no rest day is present.",
                        "improvement_hint": "Break up key sessions with easy or rest days and remove non-essential extra stress.",
                    },
                ],
            }

        lines.extend(
            [
                "Example A - stronger goal/coherence case",
                strong_case["plan_snippet"],
                _safe_json_snippet({"marker_results": strong_case["marker_results"]}, max_chars=3_500),
                "",
                "Example B - weaker goal/coherence case",
                weak_case["plan_snippet"],
                _safe_json_snippet({"marker_results": weak_case["marker_results"]}, max_chars=3_500),
                "",
            ]
        )

    elif "explanation_quality" in rubric_set:
        examples = [
            {
                "label": "Example A - strong explanation quality",
                "plan_snippet": (
                    "Thu tempo: 3 x 8 min uphill at steady threshold. Purpose: uphill lactate clearance and climbing durability for the athlete's trail race."
                ),
                "marker_results": [
                    {
                        "rubric": "explanation_quality",
                        "marker_id": "specificity",
                        "marker": "Specificity",
                        "observation": "The explanation names the exact workout and explains why it matters for the athlete's race demands.",
                        "verdict": "pass",
                        "score": 4.5,
                        "evidence": "It specifies 3 x 8 min uphill and connects it to climbing durability and lactate clearance.",
                        "improvement_hint": "Add recovery duration between reps if the athlete needs more execution detail.",
                    }
                ],
            },
            {
                "label": "Example B - weak explanation quality",
                "plan_snippet": "Thu run. Purpose: get fitter and build confidence.",
                "marker_results": [
                    {
                        "rubric": "explanation_quality",
                        "marker_id": "non_generic_language",
                        "marker": "Non-generic language",
                        "observation": "The wording is motivational but generic and does not clarify what adaptation the session targets.",
                        "verdict": "fail",
                        "score": 1.5,
                        "evidence": "The purpose says only 'get fitter and build confidence'.",
                        "improvement_hint": "Replace generic encouragement with the session's concrete physiological or race-specific purpose.",
                    }
                ],
            },
        ]
        for example in examples:
            lines.extend(
                [
                    example["label"],
                    example["plan_snippet"],
                    _safe_json_snippet({"marker_results": example["marker_results"]}, max_chars=2_500),
                    "",
                ]
            )

    elif "caution_proportionality" in rubric_set:
        examples = [
            {
                "label": "Example A - proportionate caution",
                "plan_snippet": (
                    "Sleep and HRV are missing, so the plan keeps one key session but trims total load and explicitly tells the athlete to downshift if fatigue rises."
                ),
                "marker_results": [
                    {
                        "rubric": "caution_proportionality",
                        "marker_id": "missing_data_behavioral_response",
                        "marker": "Missing data behavioral response",
                        "observation": "The plan responds to missing recovery data by being slightly more conservative rather than pretending certainty.",
                        "verdict": "pass",
                        "score": 4.0,
                        "evidence": "The key session stays, but total load is trimmed and an explicit downshift instruction is included.",
                        "improvement_hint": "Name the specific trigger for reducing intensity if fatigue or soreness appears.",
                    }
                ],
            },
            {
                "label": "Example B - poor caution handling",
                "plan_snippet": (
                    "No recovery metrics are available, but the plan still prescribes maximal intervals and a big volume jump without acknowledging uncertainty."
                ),
                "marker_results": [
                    {
                        "rubric": "caution_proportionality",
                        "marker_id": "missing_data_acknowledgment",
                        "marker": "Missing data acknowledgment",
                        "observation": "The plan behaves as if recovery data were complete even though key signals are absent.",
                        "verdict": "fail",
                        "score": 1.0,
                        "evidence": "There is no note about missing sleep, HRV, or resting HR data before prescribing harder work.",
                        "improvement_hint": "Explicitly acknowledge missing telemetry and reduce certainty in the prescription.",
                    }
                ],
            },
        ]
        for example in examples:
            lines.extend(
                [
                    example["label"],
                    example["plan_snippet"],
                    _safe_json_snippet({"marker_results": example["marker_results"]}, max_chars=2_500),
                    "",
                ]
            )

    elif "actionability" in rubric_set:
        examples = [
            {
                "label": "Example A - actionable session",
                "plan_snippet": (
                    "Sat long run: 2 h easy on rolling trail, last 20 min steady uphill, hike steep grades, carry fuel and practice race vest setup."
                ),
                "marker_results": [
                    {
                        "rubric": "actionability",
                        "marker_id": "session_clarity",
                        "marker": "Session clarity",
                        "observation": "The athlete can execute this session directly because duration, terrain, pacing, and fueling details are explicit.",
                        "verdict": "pass",
                        "score": 4.5,
                        "evidence": "The plan specifies 2 h easy, rolling trail terrain, last 20 min steady uphill, and race-vest practice.",
                        "improvement_hint": "Add an RPE range if the athlete prefers effort-based pacing cues.",
                    }
                ],
            },
            {
                "label": "Example B - vague session",
                "plan_snippet": "Sat run. Do something challenging but controlled.",
                "marker_results": [
                    {
                        "rubric": "actionability",
                        "marker_id": "followability",
                        "marker": "Followability",
                        "observation": "The athlete would have to guess duration, intensity, and terrain, so the instruction is hard to follow consistently.",
                        "verdict": "fail",
                        "score": 1.5,
                        "evidence": "No duration, pace, terrain, or workout structure is provided.",
                        "improvement_hint": "State the duration, target intensity, terrain, and any key execution rules.",
                    }
                ],
            },
        ]
        for example in examples:
            lines.extend(
                [
                    example["label"],
                    example["plan_snippet"],
                    _safe_json_snippet({"marker_results": example["marker_results"]}, max_chars=2_500),
                    "",
                ]
            )

    return lines


# ---------------------------------------------------------------------------
# Per-batch prompt and execution
# ---------------------------------------------------------------------------


def _build_batch_prompt(
    rubric_ids: list[str],
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> str:
    has_week_coherence = "plan_coherence" in rubric_ids
    rubric_text = render_rubric_batch_for_prompt(rubric_ids, style=style, primary_goal=primary_goal)
    expected = _expected_markers_for_rubrics(rubric_ids, style)

    instructions = [
        "You are evaluating specific rubrics of an endurance training plan.",
        "Score ONLY the rubrics and markers listed below - do not evaluate other rubrics.",
        "",
        "For each marker, you MUST follow this exact order in your JSON output:",
        "  1. observation: Describe what you observe in the plan relevant to this marker.",
        "     This must be written BEFORE you decide the verdict or score.",
        "     It makes your reasoning auditable.",
        "  2. verdict: pass / partial / fail",
        "  3. score: 0-5",
        "  4. evidence: Concrete quote or reference from the plan.",
        "  5. improvement_hint: A specific, actionable suggestion.",
        "",
    ]

    if has_week_coherence:
        instructions += [
            "IMPORTANT: Score the 'week_coherence' marker LAST.",
            "Only score week_coherence after you have scored all other markers in plan_coherence.",
            "week_coherence evaluates the full week as a unit, so per-session markers must come first.",
            "",
        ]

    return "\n".join(
        [
            *instructions,
            *_few_shot_examples_for_batch(rubric_ids, style=style),
            *_lifestyle_context_for_eval(lifestyle_notes),
            "## Rubrics to evaluate in this call",
            rubric_text,
            "",
            "## Expected markers - include exactly these in marker_results",
            _safe_json_snippet(expected, max_chars=8_000),
            "",
            "## Deterministic evaluation report (context)",
            _safe_json_snippet(deterministic_report, max_chars=12_000),
            "",
            "## Rollups context",
            _safe_json_snippet(rollups or {}, max_chars=8_000),
            "",
            "## Training plan JSON",
            _safe_json_snippet(plan_obj, max_chars=40_000),
            "",
            "## Output rules",
            "- Return JSON only - no markdown fences, no commentary.",
            "- Include one marker_results item for every expected marker_id.",
            "- observation MUST describe what you see before you assign a score.",
            "- evidence MUST cite specific content from the plan.",
            "- improvement_hint MUST be specific, not generic.",
        ]
    )



def _build_synthesis_prompt(
    plan_obj: dict[str, Any],
    all_marker_results: list[dict[str, Any]],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> str:
    return "\n".join(
        [
            "You have evaluated a training plan across all rubrics.",
            "Based on the marker results below, write a synthesis assessment.",
            f"Style: {style}",
            f"Primary goal: {primary_goal}",
            "",
            *_lifestyle_context_for_eval(lifestyle_notes),
            "## All marker results (from per-rubric evaluation)",
            _safe_json_snippet(all_marker_results, max_chars=25_000),
            "",
            "## Training plan JSON",
            _safe_json_snippet(plan_obj, max_chars=25_000),
            "",
            "## Output rules",
            "- Return JSON only.",
            "- summary: 2-3 sentences on overall plan quality, grounded in markers.",
            "- confidence: low / medium / high - how confident are you in the assessment?",
            "- strengths: 2-4 concrete strengths from the plan (not generic praise).",
            "- concerns: 1-3 concrete concerns tied to low-scoring markers.",
            "- suggested_improvements: 2-4 specific, actionable improvements.",
        ]
    )



def _run_rubric_batch(
    client: Any,
    cfg: SoftEvalConfig,
    rubric_ids: list[str],
    batch_name: str,
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> list[dict[str, Any]]:
    schema = _build_batch_marker_schema(batch_name)
    prompt = _build_batch_prompt(
        rubric_ids,
        plan_obj,
        deterministic_report,
        rollups,
        style=style,
        primary_goal=primary_goal,
        lifestyle_notes=lifestyle_notes,
    )

    kwargs: dict[str, Any] = {
        "model": cfg.model,
        "instructions": (
            "You are a strict endurance training-plan assessor. "
            "Score only the markers listed. "
            "Write your observation before assigning a score."
        ),
        "input": prompt,
        "reasoning": {"effort": cfg.reasoning_effort},
        "text": {"verbosity": cfg.verbosity},
        "max_output_tokens": int(os.getenv("TRAILTRAINING_SOFT_EVAL_MAX_OUTPUT_TOKENS", "6000")),
    }
    if cfg.reasoning_effort == "none" and cfg.temperature is not None:
        kwargs["temperature"] = cfg.temperature

    resp = call_with_schema(client, kwargs, schema)
    out_text = getattr(resp, "output_text", None) or str(resp)

    try:
        raw = _parse_soft_eval_json(out_text)
        results = raw.get("marker_results")
        if not isinstance(results, list) or not results:
            raise ValueError("Empty marker_results in batch response.")
        return results
    except Exception as exc:
        log.warning(
            "Batch '%s' returned unusable results (%s); falling back to marker-only repair.",
            batch_name,
            exc,
        )
        return _generate_marker_results_only(
            client,
            cfg,
            plan_obj,
            deterministic_report,
            rollups,
            style=style,
            primary_goal=primary_goal,
            lifestyle_notes=lifestyle_notes,
            rubric_ids=rubric_ids,
        )



def _run_synthesis_call(
    client: Any,
    cfg: SoftEvalConfig,
    plan_obj: dict[str, Any],
    all_marker_results: list[dict[str, Any]],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> dict[str, Any]:
    prompt = _build_synthesis_prompt(
        plan_obj,
        all_marker_results,
        rollups,
        style=style,
        primary_goal=primary_goal,
        lifestyle_notes=lifestyle_notes,
    )

    kwargs: dict[str, Any] = {
        "model": cfg.model,
        "instructions": (
            "Synthesize the marker evaluations into a concise assessment. "
            "Ground every claim in the marker evidence."
        ),
        "input": prompt,
        "reasoning": {"effort": cfg.reasoning_effort},
        "text": {"verbosity": cfg.verbosity},
        "max_output_tokens": int(os.getenv("TRAILTRAINING_SOFT_EVAL_MAX_OUTPUT_TOKENS", "4000")),
    }
    if cfg.reasoning_effort == "none" and cfg.temperature is not None:
        kwargs["temperature"] = cfg.temperature

    try:
        resp = call_with_schema(client, kwargs, _SYNTHESIS_SCHEMA)
        out_text = getattr(resp, "output_text", None) or str(resp)
        raw = _parse_soft_eval_json(out_text)
        return {
            "summary": str(raw.get("summary", "") or "").strip(),
            "confidence": _normalize_confidence(raw.get("confidence")),
            "strengths": _clean_string_list(raw.get("strengths")),
            "concerns": _clean_string_list(raw.get("concerns")),
            "suggested_improvements": _clean_string_list(raw.get("suggested_improvements")),
        }
    except Exception as exc:
        log.warning("Synthesis call failed: %s; using empty synthesis.", exc)
        return {
            "summary": "",
            "confidence": "low",
            "strengths": [],
            "concerns": [],
            "suggested_improvements": [],
        }



def _generate_marker_results_only(
    client: Any,
    cfg: SoftEvalConfig,
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str = "",
    rubric_ids: Optional[list[str]] = None,
) -> list[dict[str, Any]]:
    expected = (
        _expected_markers_for_rubrics(rubric_ids, style) if rubric_ids else _expected_markers(style)
    )
    rubric_text = (
        render_rubric_batch_for_prompt(rubric_ids, style=style, primary_goal=primary_goal)
        if rubric_ids
        else render_rubrics_for_prompt(style=style, primary_goal=primary_goal)
    )
    few_shot: list[str] = []
    if rubric_ids:
        few_shot = _few_shot_examples_for_batch(rubric_ids, style=style)
    kwargs: dict[str, Any] = {
        "model": cfg.model,
        "instructions": "Return only valid JSON. No markdown.",
        "input": "\n".join(
            [
                "Return JSON only.",
                "Your only job is to produce marker_results for every expected marker.",
                "Do not omit markers.",
                "",
                f"Style: {style}",
                f"Primary goal: {primary_goal}",
                "",
                *few_shot,
                *_lifestyle_context_for_eval(lifestyle_notes),
                "## Expected markers",
                _safe_json_snippet(expected, max_chars=15_000),
                "",
                "## Rubrics and markers",
                rubric_text,
                "",
                "## Deterministic evaluation report",
                _safe_json_snippet(deterministic_report, max_chars=15_000),
                "",
                "## Rollups context",
                _safe_json_snippet(rollups or {}, max_chars=8_000),
                "",
                "## Training plan JSON",
                _safe_json_snippet(plan_obj, max_chars=35_000),
                "",
                "## Output rules",
                "- Return one marker_results item for every expected marker_id.",
                "- Use rubric, marker_id, and marker exactly as provided.",
                "- verdict must be pass, partial, or fail.",
                "- score must be 0 to 5.",
                "- observation: what you see in the plan for this marker.",
                "- evidence must be concrete.",
                "- improvement_hint must be specific.",
            ]
        ),
        "reasoning": {"effort": "none"},
        "text": {"verbosity": "low"},
        "max_output_tokens": int(os.getenv("TRAILTRAINING_SOFT_EVAL_MAX_OUTPUT_TOKENS", "6000")),
    }
    resp = call_with_schema(client, kwargs, _marker_only_schema())
    out_text = getattr(resp, "output_text", None) or str(resp)
    raw = _parse_soft_eval_json(out_text)
    marker_results = raw.get("marker_results")
    if not isinstance(marker_results, list) or not marker_results:
        raise ValueError("Marker-only repair returned missing or empty marker_results.")
    return marker_results



def _looks_internally_broken_soft_eval(
    summary: str,
    rubric_scores: dict[str, dict[str, Any]],
    marker_results: list[dict[str, Any]],
) -> bool:
    rubric_vals = [float((item or {}).get("score", 0)) for item in rubric_scores.values()]
    marker_vals = [float(item.get("score", 0)) for item in marker_results]
    return (
        bool(str(summary).strip())
        and bool(rubric_vals)
        and bool(marker_vals)
        and max(rubric_vals) == 0.0
        and max(marker_vals) == 0.0
    )



def _too_much_output_was_locally_derived(derived_fields: list[str]) -> bool:
    derived = set(derived_fields)
    return {"strengths", "concerns", "suggested_improvements"}.issubset(derived)


# ---------------------------------------------------------------------------
# Parallel / sequential batch runners
# ---------------------------------------------------------------------------


def _run_batches_parallel(
    client: Any,
    cfg: SoftEvalConfig,
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> tuple[list[dict[str, Any]], bool]:
    all_marker_results_raw: list[dict[str, Any]] = []
    repaired = False
    max_workers = min(len(_RUBRIC_BATCHES), int(os.getenv("TRAILTRAINING_SOFT_EVAL_WORKERS", "4")))

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_batch: dict[Any, str] = {}
        for batch_name, rubric_ids in _RUBRIC_BATCHES:
            future = executor.submit(
                _run_rubric_batch,
                client,
                cfg,
                rubric_ids,
                batch_name,
                plan_obj,
                deterministic_report,
                rollups,
                style=style,
                primary_goal=primary_goal,
                lifestyle_notes=lifestyle_notes,
            )
            future_to_batch[future] = batch_name

        for future in as_completed(future_to_batch):
            batch_name = future_to_batch[future]
            try:
                batch_results = future.result()
                all_marker_results_raw.extend(batch_results)
            except Exception as exc:
                log.warning(
                    "Rubric batch '%s' failed entirely: %s. "
                    "Results for these rubrics will be empty.",
                    batch_name,
                    exc,
                )
                repaired = True

    return all_marker_results_raw, repaired



def _run_batches_sequential(
    client: Any,
    cfg: SoftEvalConfig,
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    *,
    style: str,
    primary_goal: str,
    lifestyle_notes: str,
) -> tuple[list[dict[str, Any]], bool]:
    all_marker_results_raw: list[dict[str, Any]] = []
    repaired = False
    for batch_name, rubric_ids in _RUBRIC_BATCHES:
        try:
            batch_results = _run_rubric_batch(
                client,
                cfg,
                rubric_ids,
                batch_name,
                plan_obj,
                deterministic_report,
                rollups,
                style=style,
                primary_goal=primary_goal,
                lifestyle_notes=lifestyle_notes,
            )
            all_marker_results_raw.extend(batch_results)
        except Exception as exc:
            log.warning(
                "Rubric batch '%s' failed entirely: %s. "
                "Results for these rubrics will be empty.",
                batch_name,
                exc,
            )
            repaired = True
    return all_marker_results_raw, repaired


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def evaluate_training_plan_soft(
    plan_obj: dict[str, Any],
    deterministic_report: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    cfg: SoftEvalConfig,
) -> dict[str, Any]:
    """Evaluate a training plan using decomposed per-rubric batch architecture.

    Lifestyle notes (from cfg or plan meta) are injected into every evaluator
    prompt so that schedule-constrained plans are scored against the best plan
    possible given those constraints, not against an unconstrained ideal.
    """
    if not cfg.enabled:
        raise ValueError("Soft evaluation is disabled.")

    style, primary_goal, lifestyle_notes = _resolve_style_goal_and_lifestyle(plan_obj, cfg)
    client = make_openrouter_client()

    # --- Per-rubric batch calls ---
    batch_runner = _run_batches_parallel if cfg.parallel_batches else _run_batches_sequential
    all_marker_results_raw, repaired = batch_runner(
        client,
        cfg,
        plan_obj,
        deterministic_report,
        rollups,
        style=style,
        primary_goal=primary_goal,
        lifestyle_notes=lifestyle_notes,
    )

    if not all_marker_results_raw:
        log.warning("All batches returned empty results; falling back to single-call evaluation.")
        repaired = True
        all_marker_results_raw = _generate_marker_results_only(
            client,
            cfg,
            plan_obj,
            deterministic_report,
            rollups,
            style=style,
            primary_goal=primary_goal,
            lifestyle_notes=lifestyle_notes,
        )

    # --- Normalise markers and derive rubric scores ---
    marker_results = _normalize_marker_results(all_marker_results_raw, style=style)
    rubric_scores = _derive_rubric_scores_from_markers(marker_results, style=style)
    overall_score = weighted_score_from_rubric_scores(rubric_scores, style=style)

    if _looks_internally_broken_soft_eval("placeholder", rubric_scores, marker_results):
        raise ValueError(
            "Soft evaluator returned an internally inconsistent result "
            "(non-empty narrative with all-zero scores)."
        )

    # --- Synthesis: LLM call or local derivation ---
    if cfg.skip_synthesis:
        log.info("Skipping synthesis LLM call (skip_synthesis=True); deriving feedback locally.")
        synthesis: dict[str, Any] = {
            "summary": "",
            "confidence": "medium",
            "strengths": [],
            "concerns": [],
            "suggested_improvements": [],
        }
    else:
        synthesis = _run_synthesis_call(
            client,
            cfg,
            plan_obj,
            marker_results,
            rollups,
            style=style,
            primary_goal=primary_goal,
            lifestyle_notes=lifestyle_notes,
        )

    # --- Apply feedback fallbacks ---
    strengths, concerns, suggested_improvements, feedback_derived = _build_feedback_lists(
        synthesis,
        rubric_scores,
        marker_results,
    )

    if cfg.skip_synthesis:
        feedback_derived = sorted(set(["strengths", "concerns", "suggested_improvements"]))

    if _too_much_output_was_locally_derived(feedback_derived) and not cfg.skip_synthesis:
        log.warning("Synthesis output required heavy local fallback; results may be lower quality.")
        repaired = True

    derived_fields = sorted(set(["rubric_scores", *feedback_derived]))
    if cfg.skip_synthesis and "summary" not in derived_fields:
        derived_fields = sorted(set([*derived_fields, "summary"]))

    payload = {
        "model": cfg.model,
        "style": style,
        "primary_goal": primary_goal,
        "summary": synthesis["summary"],
        "overall_score": overall_score,
        "grade": grade_from_score(overall_score),
        "confidence": synthesis["confidence"],
        "rubric_scores": rubric_scores,
        "marker_results": marker_results,
        "strengths": strengths,
        "concerns": concerns,
        "suggested_improvements": suggested_improvements,
        "repaired": repaired,
        "derived_fields": derived_fields,
    }

    return SoftAssessmentArtifact.model_validate(payload).model_dump(mode="json")


# ---------------------------------------------------------------------------
# Forced-ranking comparison
# ---------------------------------------------------------------------------


def compare_plans(
    plan_a: dict[str, Any],
    plan_b: dict[str, Any],
    rollups: Optional[dict[str, Any]],
    cfg: SoftEvalConfig,
) -> dict[str, Any]:
    style, primary_goal, lifestyle_notes = _resolve_style_goal_and_lifestyle(plan_a, cfg)
    client = make_openrouter_client()

    prompt = "\n".join(
        [
            "Compare these two training plans and determine which is better.",
            "First reason through what you observe in each plan, then give your preference.",
            "Do NOT simply prefer the longer or more complex plan - prefer the one that better",
            "serves the athlete's goal given their current state.",
            "",
            f"Style: {style}",
            f"Primary goal: {primary_goal}",
            "",
            *_lifestyle_context_for_eval(lifestyle_notes),
            "## Plan A",
            _safe_json_snippet(plan_a, max_chars=25_000),
            "",
            "## Plan B",
            _safe_json_snippet(plan_b, max_chars=25_000),
            "",
            "## Context (rollups)",
            _safe_json_snippet(rollups or {}, max_chars=8_000),
            "",
            "## Output rules",
            "- preferred: 'plan_a', 'plan_b', or 'tie'",
            "- reasoning: 3-5 sentences explaining your choice, citing specific differences.",
            "- plan_a_advantages: 2-4 specific advantages of Plan A over Plan B.",
            "- plan_b_advantages: 2-4 specific advantages of Plan B over Plan A.",
            "- Return JSON only.",
        ]
    )

    kwargs: dict[str, Any] = {
        "model": cfg.model,
        "instructions": (
            "Compare two training plans. Reason carefully before concluding. "
            "Be specific about what makes one plan better than the other."
        ),
        "input": prompt,
        "reasoning": {"effort": cfg.reasoning_effort},
        "text": {"verbosity": cfg.verbosity},
    }
    if cfg.reasoning_effort == "none" and cfg.temperature is not None:
        kwargs["temperature"] = cfg.temperature

    resp = call_with_schema(client, kwargs, _COMPARE_PLANS_SCHEMA)
    out_text = getattr(resp, "output_text", None) or str(resp)

    try:
        raw = json.loads(extract_json_object(out_text))
    except Exception as exc:
        log.warning("compare_plans JSON parse failed: %s", exc)
        return {
            "preferred": "tie",
            "reasoning": "Could not parse comparison response.",
            "plan_a_advantages": [],
            "plan_b_advantages": [],
        }

    return {
        "preferred": str(raw.get("preferred", "tie")),
        "reasoning": str(raw.get("reasoning", "")).strip(),
        "plan_a_advantages": _clean_string_list(raw.get("plan_a_advantages", [])),
        "plan_b_advantages": _clean_string_list(raw.get("plan_b_advantages", [])),
    }
